Testes automatizados entram junto com a Fase 3 (interpolação/keyframes).
