Módulos nativos (FFmpeg, OpenCV, Vulkan/Metal) — Fases 6-7
