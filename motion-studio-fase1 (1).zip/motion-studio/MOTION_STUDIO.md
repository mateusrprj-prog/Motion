# Motion Studio — Documento Mestre (contexto do projeto)

> **Última atualização:** Fase 1 — Fundação (v0.1.3: build simplificado, foco no APK)

## ⚠️ REGRA PERMANENTE PARA A IA
**A cada mudança, a IA DEVE enviar este arquivo `MOTION_STUDIO.md` atualizado** (status das fases, changelog, decisões, limitações, backlog), junto com o `.zip` do projeto. Sem exceção. Se uma resposta não alterar código, ainda assim informar "MD sem alterações".
Outras regras: desenvolver um editor REAL (sem botões falsos, sem vídeos pré-gravados, sem timeline decorativa); registrar limitações em vez de simular; uma fase por vez; testar antes de avançar; nunca expor chaves de API no app.

## Fluxo de trabalho do usuário
- Dispositivo de teste: **Xiaomi POCO X7 Pro** (Android, arm64-v8a). Prioridade total em Android; iOS depois.
- Só há esse aparelho. Não há computador de desenvolvimento: **a IA gera um `.zip` + `build.yml` separado → usuário sobe os dois na raiz do GitHub (upload web não aceita pastas) → o workflow compila o APK** (artifact `motion-studio-apk` na aba Actions) → instala no celular.
- Se o build falhar: o usuário cola o log do GitHub Actions aqui e a IA corrige.

## Visão
App mobile de edição de vídeo, motion design e VFX inspirado no After Effects. Nome provisório: Motion Studio. Visual: fundo escuro, preto/grafite, destaques roxo (#8B5CF6) e azul (#3B82F6).

## Stack
React Native + Expo (SDK 54) + TypeScript + Expo Router (`src/app`) · Zustand · Reanimated (entra na Fase 2/3) · **Skia (Fase 2+)** para render GPU/shaders SkSL · FFmpeg (ffmpeg-kit, atenção à licença LGPL) para export · Supabase (nuvem/auth, opcional) · backend próprio para proteger chaves de IA · GitHub Actions.

## Arquitetura (princípios)
1. **Interface, motor de composição e renderizador separados.**
2. Modelo de projeto = JSON versionado (`.msproj`) com migrações (`src/projects`).
3. `renderFrame(project, t)` função pura → preview e exportação usam o mesmo código.
4. **Efeitos = módulos independentes** em registry (`src/effects`): `{id, params, shader/pass, ui, serialize}`. Novo efeito = nova pasta + registro.
5. **Undo/redo por padrão de comandos.** A IA emite os mesmos comandos (ganha prévia e desfazer).
6. Preview em resolução reduzida; render final em qualidade total. Carregamento sob demanda.
7. Partículas determinísticas por seed (preview == export).

## Status das fases
- [x] **Fase 1 — Fundação**: Expo+TS+Router, tema escuro, tela inicial (novo projeto, projetos recentes, importar mídia, excluir), modelo de projeto versionado + migrações, salvamento seguro (tmp+bak), importação com validação de extensão, registry de efeitos (esqueleto), CI de build APK.
- [ ] **Fase 2 — Editor funcional**: visualizador Skia, timeline, camadas (criar/excluir/duplicar/reordenar/bloquear/ocultar), reprodução, corte/mover, **undo/redo (comandos)**, autosave, miniaturas reais.
- [ ] **Fase 3 — Animação**: keyframes (posição, escala, rotação, opacidade, âncora, cor), interpolação (linear, ease, bezier), editor de curvas, **primeiros testes automatizados (Jest)**.
- [ ] **Fase 4 — Efeitos**: motor de efeitos SkSL; Gaussian Blur, Glow, Drop Shadow, Color Correction, Sharpen, Noise, Vignette, Chromatic Aberration, RGB Split, Pixelate, Posterize, Glitch, Camera Shake, Displacement, Wave Warp, Lens Distortion.
- [ ] **Fase 5 — Motion design**: texto animado (typewriter, slide, bounce, reveal, glitch, por palavra/caractere), formas vetoriais, máscaras (retangular, circular, Bezier, feather), presets executáveis, **Mesh Warp → Puppet Pin → Liquify** (malha com `drawVertices`).
- [ ] **Fase 6 — Vídeo e áudio**: decodificação de vídeo, trilhas de áudio, waveform, fades, sincronização, **export MP4 real** (render offscreen nativo + FFmpeg), cancelamento/progresso.
- [ ] **Fase 7 — Avançados**: chroma key, tracking, partículas (emissores, gravidade, fumaça/fogo/chuva/neve), motion blur, Vector Blur, Echo, Time Remapping, **Optical Flow / Pixel Motion / Rotoscoping** (módulos nativos), 3D (câmera, luzes, X/Y/Z).
- [ ] **Fase 8 — IA**: assistente que gera comandos estruturados (não só texto), prévia antes de confirmar, undo, chaves só no backend, remoção de fundo por IA.
- [ ] **Fase 9 — Finalização**: testes, otimização, build Android/iOS, docs finais, Supabase/sincronização nuvem, perfil/configurações, modelos.

## Seção 24 — Motor avançado (plano de implementação real)
- **Puppet Pin**: malha triangulada (Delaunay sobre contorno do alpha + pontos internos) + deformação ARAP/RBF; rigidez = parâmetro do solver; expansão = dilatação da malha; render com `drawVertices` texturizado (preserva transparência). Múltiplas regiões de controle.
- **Mesh Warp**: grade N×M, vértices editáveis, interpolação Catmull-Rom, keyframes por vértice (reaproveita a malha do Puppet).
- **Liquify**: campo de deslocamento 2D editado por pincéis (empurrar, expandir, contrair, girar, suavizar); congelar = máscara; restaurar = relaxar campo.
- **Displacement / Turbulent / Vector Blur / Echo / Lens Distortion / Chromatic Aberration / Camera Shake**: shaders SkSL; Echo e Time Remapping usam buffer de frames.
- **Partículas**: pool com seed + `drawAtlas`. **Rotoscoping/Optical Flow**: nativo (OpenCV/Vulkan) + segmentação (SAM leve ou backend).
- Cada efeito: parâmetros, UI própria, keyframes, prévia, render real, undo/redo, salvo no projeto.

## Backlog / ideias adicionadas
- Presets: textos, transições, glitch, cinematográfico, neon, partículas, logo, intros; salvar/compartilhar.
- Áudio multi-faixa, waveform, fades. Guias/grades, zoom no visualizador, pré-composições, agrupamento, copiar/colar animações.
- Tela inicial futura: modelos de projeto, projetos salvos na nuvem, perfil, configurações (**não implementados ainda — não há botões falsos**).
- Recuperação após interrupção, backups, cache de efeitos, preview adaptativo.
- Compatibilidade iOS (Metal) após Android estável.

## Limitações conhecidas (regra 13)
1. Fase 1 **não foi compilada pela IA** (sem rede no ambiente). Possível ajuste de versões no 1º build; o workflow roda `npx expo install --fix`.
2. O editor (`/editor/[id]`) só mostra dados do projeto; visualizador/timeline = Fase 2.
3. Miniaturas de projeto são só proporção; miniaturas reais = Fase 2.
4. Optical Flow, rotoscoping por IA, colisões de partículas e export em tempo real exigem módulos nativos (Fases 6–7).
5. 4K e efeitos pesados dependem do aparelho.
6. Biblioteca de mídia é global; vínculo mídia↔camada na Fase 2.
7. O workflow não roda typecheck separado (simplificado); erros de TypeScript aparecem no build do APK.

## Como publicar (passo a passo)
1. **Uma vez só:** no GitHub, *Add file → Create new file*, digite o nome `.github/workflows/build.yml` (as barras criam as pastas) e cole o conteúdo do `build.yml` enviado separadamente.
2. Suba o `.zip` do projeto (**sem extrair**) na raiz do repositório. Pode ter qualquer nome. Se houver vários `.zip`, o workflow usa o mais recente; apague os antigos para evitar confusão.
3. Aba **Actions** → "Build Android APK" (roda a cada push em `main`/`master` ou manualmente).
4. Baixe o artifact `motion-studio-apk` e instale no POCO X7 Pro.
5. O `build.yml` não muda entre fases; a IA só reenviará se precisar alterá-lo. Apague zips antigos do repositório.

## Decisões técnicas
- Expo SDK 54, `expo-file-system/legacy` (API estável de strings/cópia).
- APK release assinado com keystore de debug do prebuild (suficiente para testes; assinatura própria depois).
- Build só `arm64-v8a` (rápido e leve; POCO X7 Pro).
- Pastas `android/` e `ios/` não ficam no projeto (geradas no CI via `expo prebuild`).
- `build.yml` genérico: acha qualquer `.zip` no repositório, extrai e compila; não depende do nome do zip nem da pasta interna.
- Alias `@/*` → `src/*`.

## Changelog
- **0.1.3**: foco só no APK. Removidos `react-native-reanimated` e `react-native-worklets` da Fase 1 (não usados ainda; maior risco de falha no build nativo) — voltam na Fase 2/3. `build.yml` reescrito: escolhe o zip mais recente por data do commit, `--legacy-peer-deps`, mais memória pro Gradle, sobe relatório de erro quando falha.
- **0.1.2**: `build.yml` sem `android-actions/setup-android` (falhava com "Failed to find package 'tools'"); usa o Android SDK já presente no runner ubuntu-latest e só aceita licenças. Zip do projeto inalterado.
- **0.1.1**: `build.yml` entregue separado do zip e genérico (qualquer .zip); `.github` removido do zip.
- **0.1.0 — Fase 1**: fundação, tela inicial, projetos, importação, schema v1, registry de efeitos, workflow de build.
