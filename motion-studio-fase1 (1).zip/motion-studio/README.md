# Motion Studio
Editor mobile de motion design e VFX (React Native + Expo + Skia). Contexto completo, fases e regras: veja [MOTION_STUDIO.md](./MOTION_STUDIO.md).

```bash
npm install && npx expo install --fix
npx expo prebuild --platform android && npx expo run:android
```
O APK é gerado automaticamente por GitHub Actions (`.github/workflows/build.yml`).
