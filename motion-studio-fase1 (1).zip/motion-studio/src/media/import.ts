import * as DocumentPicker from 'expo-document-picker';
import * as FS from 'expo-file-system/legacy';
import { MediaAsset, MediaKind, uid } from '@/projects/schema';

const MEDIA_DIR = (FS.documentDirectory ?? '') + 'media/';
const LIB = MEDIA_DIR + 'library.json';

const EXT: Record<string, MediaKind> = {
  png: 'image', jpg: 'image', jpeg: 'image', webp: 'image',
  mp4: 'video', mov: 'video', m4v: 'video',
  wav: 'audio', mp3: 'audio', m4a: 'audio', aac: 'audio',
};

async function ensureDir() {
  if (!(await FS.getInfoAsync(MEDIA_DIR)).exists) await FS.makeDirectoryAsync(MEDIA_DIR, { intermediates: true });
}

export async function loadLibrary(): Promise<MediaAsset[]> {
  await ensureDir();
  if (!(await FS.getInfoAsync(LIB)).exists) return [];
  try { return JSON.parse(await FS.readAsStringAsync(LIB)); } catch { return []; }
}
async function saveLibrary(items: MediaAsset[]) {
  await FS.writeAsStringAsync(LIB, JSON.stringify(items));
}

// Valida a extensão, copia o arquivo para o armazenamento do app e registra na biblioteca.
export async function importMedia(): Promise<{ added: MediaAsset[]; rejected: string[] }> {
  const res = await DocumentPicker.getDocumentAsync({
    type: ['image/*', 'video/*', 'audio/*'], multiple: true, copyToCacheDirectory: true,
  });
  if (res.canceled) return { added: [], rejected: [] };
  await ensureDir();
  const lib = await loadLibrary();
  const added: MediaAsset[] = [];
  const rejected: string[] = [];
  for (const a of res.assets) {
    const ext = (a.name.split('.').pop() ?? '').toLowerCase();
    const kind = EXT[ext];
    if (!kind) { rejected.push(a.name); continue; }
    const id = uid();
    const dest = `${MEDIA_DIR}${id}.${ext}`;
    await FS.copyAsync({ from: a.uri, to: dest });
    added.push({ id, name: a.name, uri: dest, kind, mimeType: a.mimeType, size: a.size, addedAt: Date.now() });
  }
  if (added.length) await saveLibrary([...added, ...lib]);
  return { added, rejected };
}
