import * as FS from 'expo-file-system/legacy';
import { Project } from './schema';
import { migrate } from './migrations';

const DIR = (FS.documentDirectory ?? '') + 'projects/';
const file = (id: string) => `${DIR}${id}.msproj`;

async function ensureDir() {
  const info = await FS.getInfoAsync(DIR);
  if (!info.exists) await FS.makeDirectoryAsync(DIR, { intermediates: true });
}

// Escrita segura: grava em .tmp e só então troca, mantendo um .bak do anterior.
export async function saveProject(p: Project): Promise<void> {
  await ensureDir();
  const next: Project = { ...p, updatedAt: Date.now() };
  const target = file(p.id);
  const tmp = target + '.tmp';
  await FS.writeAsStringAsync(tmp, JSON.stringify(next));
  const old = await FS.getInfoAsync(target);
  if (old.exists) {
    await FS.deleteAsync(target + '.bak', { idempotent: true });
    await FS.moveAsync({ from: target, to: target + '.bak' });
  }
  await FS.moveAsync({ from: tmp, to: target });
}

export async function loadProject(id: string): Promise<Project> {
  try {
    return migrate(JSON.parse(await FS.readAsStringAsync(file(id))));
  } catch (e) {
    const bak = file(id) + '.bak';
    if ((await FS.getInfoAsync(bak)).exists) return migrate(JSON.parse(await FS.readAsStringAsync(bak)));
    throw e;
  }
}

export async function listProjects(): Promise<Project[]> {
  await ensureDir();
  const names = (await FS.readDirectoryAsync(DIR)).filter((n) => n.endsWith('.msproj'));
  const out: Project[] = [];
  for (const n of names) {
    try { out.push(await loadProject(n.replace('.msproj', ''))); } catch { /* ignora corrompidos */ }
  }
  return out.sort((a, b) => b.updatedAt - a.updatedAt);
}

export async function deleteProject(id: string): Promise<void> {
  await FS.deleteAsync(file(id), { idempotent: true });
  await FS.deleteAsync(file(id) + '.bak', { idempotent: true });
}
