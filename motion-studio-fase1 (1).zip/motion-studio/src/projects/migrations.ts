import { Project, SCHEMA_VERSION } from './schema';

// Cada migração leva a versão N para N+1. Projetos antigos continuam abrindo.
const migrations: Record<number, (p: any) => any> = {
  // 1: (p) => ({ ...p, schemaVersion: 2, novoCampo: ... }),
};

export function migrate(raw: any): Project {
  if (!raw || typeof raw !== 'object' || typeof raw.schemaVersion !== 'number') {
    throw new Error('Arquivo de projeto inválido.');
  }
  if (raw.schemaVersion > SCHEMA_VERSION) {
    throw new Error('Projeto criado em uma versão mais nova do app. Atualize o Motion Studio.');
  }
  let p = raw;
  while (p.schemaVersion < SCHEMA_VERSION) {
    const step = migrations[p.schemaVersion];
    if (!step) throw new Error(`Sem migração a partir da versão ${p.schemaVersion}.`);
    p = step(p);
  }
  if (!p.composition || !Array.isArray(p.composition.layers)) throw new Error('Composição inválida.');
  return p as Project;
}
