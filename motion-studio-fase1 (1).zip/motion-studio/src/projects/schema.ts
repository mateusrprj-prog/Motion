// Modelo de projeto versionado (.msproj = JSON). Fonte única de verdade:
// preview e exportação leem este mesmo modelo.
export const SCHEMA_VERSION = 1;

export type LayerType =
  | 'video' | 'image' | 'text' | 'shape' | 'audio' | 'solid' | 'precomp' | 'camera' | 'null';

export type Interpolation = 'linear' | 'easeIn' | 'easeOut' | 'easeInOut' | 'bezier' | 'hold';
export type ParamValue = number | boolean | string | number[];

export interface Keyframe<T = ParamValue> {
  time: number; // segundos
  value: T;
  interpolation: Interpolation;
  bezier?: [number, number, number, number];
}
export interface AnimatedProperty<T = ParamValue> {
  value: T;
  keyframes: Keyframe<T>[];
}
export const prop = <T,>(value: T): AnimatedProperty<T> => ({ value, keyframes: [] });

export interface Transform {
  positionX: AnimatedProperty<number>;
  positionY: AnimatedProperty<number>;
  scaleX: AnimatedProperty<number>;
  scaleY: AnimatedProperty<number>;
  rotation: AnimatedProperty<number>;
  opacity: AnimatedProperty<number>;
  anchorX: AnimatedProperty<number>;
  anchorY: AnimatedProperty<number>;
}
export interface EffectInstance {
  id: string;
  effectId: string;
  enabled: boolean;
  params: Record<string, AnimatedProperty>;
}
export interface Mask {
  id: string;
  mode: 'add' | 'subtract' | 'intersect';
  inverted: boolean;
  feather: AnimatedProperty<number>;
  opacity: AnimatedProperty<number>;
  expansion: AnimatedProperty<number>;
  points: { x: number; y: number; inX: number; inY: number; outX: number; outY: number }[];
}
export interface Layer {
  id: string;
  type: LayerType;
  name: string;
  startTime: number;
  duration: number;
  inPoint: number;
  locked: boolean;
  hidden: boolean;
  parentId?: string;
  mediaId?: string;
  transform: Transform;
  effects: EffectInstance[];
  masks: Mask[];
}
export type MediaKind = 'image' | 'video' | 'audio';
export interface MediaAsset {
  id: string;
  name: string;
  uri: string;
  kind: MediaKind;
  mimeType?: string;
  size?: number;
  addedAt: number;
}
export interface Composition {
  width: number;
  height: number;
  fps: number;
  duration: number;
  backgroundColor: string;
  layers: Layer[]; // ordem = ordem de renderização (0 = fundo)
}
export interface Project {
  schemaVersion: number;
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  composition: Composition;
  media: MediaAsset[];
}

export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

export const defaultTransform = (w: number, h: number): Transform => ({
  positionX: prop(w / 2), positionY: prop(h / 2),
  scaleX: prop(100), scaleY: prop(100),
  rotation: prop(0), opacity: prop(100),
  anchorX: prop(0), anchorY: prop(0),
});

export function createProject(name: string, width: number, height: number, fps = 30): Project {
  const now = Date.now();
  return {
    schemaVersion: SCHEMA_VERSION, id: uid(), name, createdAt: now, updatedAt: now,
    composition: { width, height, fps, duration: 10, backgroundColor: '#000000', layers: [] },
    media: [],
  };
}
