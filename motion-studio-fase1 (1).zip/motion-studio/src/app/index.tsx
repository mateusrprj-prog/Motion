import React, { useEffect, useState } from 'react';
import { Alert, FlatList, Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppStore } from '@/store/useAppStore';
import { NewProjectModal } from '@/components/NewProjectModal';
import { colors, radius, space } from '@/theme';

export default function Home() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { projects, media, refresh, create, remove, importFiles } = useAppStore();
  const [modal, setModal] = useState(false);

  useEffect(() => { refresh(); }, [refresh]);

  const onImport = async () => {
    try {
      const { added, rejected } = await importFiles();
      if (rejected.length) Alert.alert('Formato não suportado', rejected.join('\n'));
      else if (added) Alert.alert('Importado', `${added} arquivo(s) na biblioteca.`);
    } catch (e: any) { Alert.alert('Erro ao importar', String(e?.message ?? e)); }
  };

  return (
    <View style={[s.root, { paddingTop: insets.top + space.lg }]}>
      <Text style={s.brand}>Motion Studio</Text>
      <View style={s.actions}>
        <Pressable style={[s.btn, s.primary]} onPress={() => setModal(true)}>
          <Text style={s.btnText}>Novo projeto</Text>
        </Pressable>
        <Pressable style={[s.btn, s.secondary]} onPress={onImport}>
          <Text style={s.btnText}>Importar mídia</Text>
        </Pressable>
      </View>

      <FlatList
        data={projects}
        keyExtractor={(p) => p.id}
        contentContainerStyle={{ paddingBottom: insets.bottom + space.xl }}
        ListHeaderComponent={<Text style={s.section}>Projetos recentes</Text>}
        ListEmptyComponent={<Text style={s.empty}>Nenhum projeto ainda. Toque em “Novo projeto” para começar.</Text>}
        ListFooterComponent={
          <View>
            <Text style={s.section}>Mídia importada ({media.length})</Text>
            {media.length === 0 ? <Text style={s.empty}>Importe imagens, vídeos ou áudio para usar nos projetos.</Text> : (
              <FlatList horizontal data={media} keyExtractor={(m) => m.id} showsHorizontalScrollIndicator={false}
                renderItem={({ item }) => (
                  <View style={s.mediaItem}>
                    {item.kind === 'image'
                      ? <Image source={{ uri: item.uri }} style={s.mediaThumb} />
                      : <View style={[s.mediaThumb, s.mediaIcon]}><Text style={s.mediaKind}>{item.kind === 'video' ? 'Vídeo' : 'Áudio'}</Text></View>}
                    <Text numberOfLines={1} style={s.mediaName}>{item.name}</Text>
                  </View>
                )} />
            )}
            <Text style={s.hint}>Segure um projeto para excluir.</Text>
          </View>
        }
        renderItem={({ item }) => {
          const { width, height, fps } = item.composition;
          const wide = width >= height;
          const ratio = width / height;
          return (
            <Pressable style={s.card} onPress={() => router.push(`/editor/${item.id}`)}
              onLongPress={() => Alert.alert('Excluir projeto', `Excluir “${item.name}”?`, [
                { text: 'Cancelar', style: 'cancel' },
                { text: 'Excluir', style: 'destructive', onPress: () => remove(item.id) },
              ])}>
              <View style={s.thumbBox}>
                <View style={[s.thumb, wide ? { width: 52, height: 52 / ratio } : { height: 52, width: 52 * ratio }]} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={s.cardTitle}>{item.name}</Text>
                <Text style={s.cardMeta}>{width}×{height} · {fps} fps · {new Date(item.updatedAt).toLocaleDateString()}</Text>
              </View>
            </Pressable>
          );
        }}
      />

      <NewProjectModal visible={modal} onClose={() => setModal(false)}
        onCreate={async (n, w, h, f) => { setModal(false); const p = await create(n, w, h, f); router.push(`/editor/${p.id}`); }} />
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg, paddingHorizontal: space.lg },
  brand: { color: colors.text, fontSize: 28, fontWeight: '800', letterSpacing: -0.5, marginBottom: space.lg },
  actions: { flexDirection: 'row', gap: space.md, marginBottom: space.md },
  btn: { flex: 1, paddingVertical: 14, borderRadius: radius.md, alignItems: 'center' },
  primary: { backgroundColor: colors.purple },
  secondary: { backgroundColor: colors.panel, borderWidth: 1, borderColor: colors.blue },
  btnText: { color: colors.text, fontWeight: '700' },
  section: { color: colors.text, fontSize: 16, fontWeight: '700', marginTop: space.xl, marginBottom: space.md },
  empty: { color: colors.textDim, lineHeight: 20 },
  card: { flexDirection: 'row', alignItems: 'center', gap: space.md, backgroundColor: colors.surface, borderRadius: radius.md, padding: space.md, marginBottom: space.sm, borderWidth: 1, borderColor: colors.border },
  thumbBox: { width: 64, height: 64, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.panel, borderRadius: radius.sm },
  thumb: { backgroundColor: '#000', borderWidth: 1, borderColor: colors.purple, borderRadius: 3 },
  cardTitle: { color: colors.text, fontSize: 16, fontWeight: '600' },
  cardMeta: { color: colors.textDim, fontSize: 12, marginTop: 2 },
  mediaItem: { width: 92, marginRight: space.sm },
  mediaThumb: { width: 92, height: 92, borderRadius: radius.sm, backgroundColor: colors.panel },
  mediaIcon: { alignItems: 'center', justifyContent: 'center' },
  mediaKind: { color: colors.blue, fontWeight: '600' },
  mediaName: { color: colors.textDim, fontSize: 11, marginTop: 4 },
  hint: { color: colors.textDim, fontSize: 11, textAlign: 'center', paddingVertical: space.lg },
});
