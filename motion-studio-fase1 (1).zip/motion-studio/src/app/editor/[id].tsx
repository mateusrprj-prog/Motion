import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { loadProject } from '@/projects/storage';
import { Project } from '@/projects/schema';
import { colors, radius, space } from '@/theme';

// Fase 1: carrega o projeto salvo e mostra seus dados reais.
// Visualizador, timeline e camadas chegam na Fase 2.
export default function Editor() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [project, setProject] = useState<Project | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadProject(String(id)).then(setProject).catch((e) => setError(String(e?.message ?? e)));
  }, [id]);

  return (
    <View style={[s.root, { paddingTop: insets.top + space.lg }]}>
      <Pressable onPress={() => router.back()}><Text style={s.back}>Voltar</Text></Pressable>
      {error ? <Text style={s.err}>{error}</Text> : !project ? <Text style={s.dim}>Abrindo projeto…</Text> : (
        <View style={s.card}>
          <Text style={s.title}>{project.name}</Text>
          <Text style={s.dim}>{project.composition.width}×{project.composition.height} · {project.composition.fps} fps · {project.composition.duration}s</Text>
          <Text style={s.dim}>Camadas: {project.composition.layers.length} · Formato v{project.schemaVersion}</Text>
          <Text style={s.note}>O visualizador, a timeline e as camadas chegam na Fase 2.</Text>
        </View>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg, padding: space.lg },
  back: { color: colors.blue, fontSize: 16, marginBottom: space.lg },
  card: { backgroundColor: colors.surface, borderRadius: radius.md, padding: space.xl, borderWidth: 1, borderColor: colors.border, gap: 6 },
  title: { color: colors.text, fontSize: 22, fontWeight: '700' },
  dim: { color: colors.textDim },
  note: { color: colors.purple, marginTop: space.md },
  err: { color: colors.danger },
});
