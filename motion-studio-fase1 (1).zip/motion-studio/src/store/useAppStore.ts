import { create } from 'zustand';
import { MediaAsset, Project, createProject } from '@/projects/schema';
import { deleteProject, listProjects, saveProject } from '@/projects/storage';
import { importMedia, loadLibrary } from '@/media/import';

interface AppState {
  projects: Project[];
  media: MediaAsset[];
  loading: boolean;
  refresh: () => Promise<void>;
  create: (name: string, w: number, h: number, fps: number) => Promise<Project>;
  remove: (id: string) => Promise<void>;
  importFiles: () => Promise<{ added: number; rejected: string[] }>;
}

export const useAppStore = create<AppState>((set, get) => ({
  projects: [], media: [], loading: true,
  refresh: async () => {
    const [projects, media] = await Promise.all([listProjects(), loadLibrary()]);
    set({ projects, media, loading: false });
  },
  create: async (name, w, h, fps) => {
    const p = createProject(name.trim() || 'Sem título', w, h, fps);
    await saveProject(p);
    await get().refresh();
    return p;
  },
  remove: async (id) => { await deleteProject(id); await get().refresh(); },
  importFiles: async () => {
    const { added, rejected } = await importMedia();
    await get().refresh();
    return { added: added.length, rejected };
  },
}));
