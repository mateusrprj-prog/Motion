import React, { useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, radius, space } from '@/theme';

const PRESETS = [
  { label: '16:9  1920×1080', w: 1920, h: 1080 },
  { label: '9:16  1080×1920', w: 1080, h: 1920 },
  { label: '1:1  1080×1080', w: 1080, h: 1080 },
  { label: '4:5  1080×1350', w: 1080, h: 1350 },
];
const FPS = [24, 30, 60];

export function NewProjectModal({ visible, onClose, onCreate }: {
  visible: boolean; onClose: () => void;
  onCreate: (name: string, w: number, h: number, fps: number) => void;
}) {
  const [name, setName] = useState('');
  const [preset, setPreset] = useState(0);
  const [fps, setFps] = useState(30);
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={s.backdrop}>
        <View style={s.card}>
          <Text style={s.title}>Novo projeto</Text>
          <TextInput value={name} onChangeText={setName} placeholder="Nome do projeto"
            placeholderTextColor={colors.textDim} style={s.input} />
          <Text style={s.label}>Formato</Text>
          <View style={s.row}>
            {PRESETS.map((p, i) => (
              <Pressable key={p.label} onPress={() => setPreset(i)} style={[s.chip, i === preset && s.chipOn]}>
                <Text style={s.chipText}>{p.label}</Text>
              </Pressable>
            ))}
          </View>
          <Text style={s.label}>Quadros por segundo</Text>
          <View style={s.row}>
            {FPS.map((f) => (
              <Pressable key={f} onPress={() => setFps(f)} style={[s.chip, f === fps && s.chipOn]}>
                <Text style={s.chipText}>{f} fps</Text>
              </Pressable>
            ))}
          </View>
          <View style={[s.row, { marginTop: space.xl }]}>
            <Pressable onPress={onClose} style={[s.btn, s.btnGhost]}><Text style={s.btnText}>Cancelar</Text></Pressable>
            <Pressable onPress={() => { onCreate(name, PRESETS[preset].w, PRESETS[preset].h, fps); setName(''); }}
              style={[s.btn, s.btnPrimary]}><Text style={s.btnText}>Criar projeto</Text></Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: '#000A', justifyContent: 'center', padding: space.xl },
  card: { backgroundColor: colors.surface, borderRadius: radius.lg, padding: space.xl, borderWidth: 1, borderColor: colors.border },
  title: { color: colors.text, fontSize: 20, fontWeight: '700', marginBottom: space.lg },
  input: { backgroundColor: colors.panel, color: colors.text, borderRadius: radius.sm, padding: space.md, marginBottom: space.lg },
  label: { color: colors.textDim, fontSize: 13, marginBottom: space.sm, marginTop: space.sm },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: space.sm },
  chip: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: radius.sm, backgroundColor: colors.panel, borderWidth: 1, borderColor: colors.border },
  chipOn: { borderColor: colors.purple, backgroundColor: '#8B5CF622' },
  chipText: { color: colors.text, fontSize: 13 },
  btn: { flex: 1, padding: 14, borderRadius: radius.md, alignItems: 'center' },
  btnGhost: { backgroundColor: colors.panel },
  btnPrimary: { backgroundColor: colors.purple },
  btnText: { color: colors.text, fontWeight: '600' },
});
