export const colors = {
  bg: '#0B0B10',
  surface: '#14141C',
  panel: '#1C1C27',
  border: '#2B2B3B',
  text: '#F2F2F7',
  textDim: '#9A9AB2',
  purple: '#8B5CF6',
  blue: '#3B82F6',
  danger: '#F0506E',
};
export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24 };
export const radius = { sm: 8, md: 14, lg: 20 };
