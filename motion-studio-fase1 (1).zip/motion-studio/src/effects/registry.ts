import { EffectModule } from './types';

const registry = new Map<string, EffectModule>();
export const registerEffect = (m: EffectModule) => { registry.set(m.id, m); };
export const getEffect = (id: string) => registry.get(id);
export const listEffects = () => Array.from(registry.values());
