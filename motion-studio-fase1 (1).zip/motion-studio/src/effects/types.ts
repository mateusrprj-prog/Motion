import { ParamValue } from '@/projects/schema';

export interface ParamDef {
  key: string;
  label: string;
  type: 'number' | 'boolean' | 'color' | 'point';
  default: ParamValue;
  min?: number; max?: number; step?: number;
  animatable: boolean;
}
// Cada efeito é um módulo independente. Na Fase 4 ganha `shader`/`pass` (Skia SkSL).
export interface EffectModule {
  id: string;
  name: string;
  category: 'basic' | 'advanced' | 'distortion' | 'time' | 'particles';
  version: number;
  params: ParamDef[];
}
