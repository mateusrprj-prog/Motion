import { registerEffect } from '../registry';

// Adicionar um efeito = criar o módulo e registrá-lo aqui. Sem tocar no resto do app.
// (Renderização real via shader: Fase 4. Ainda não exposto na UI.)
registerEffect({
  id: 'brightness', name: 'Brightness', category: 'basic', version: 1,
  params: [{ key: 'amount', label: 'Intensidade', type: 'number', default: 0, min: -100, max: 100, step: 1, animatable: true }],
});
