// Fase futura — ver MOTION_STUDIO.md
