import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, radius } from '@/theme';

export function NumberField({ label, value, onCommit, step = 1, min, max, decimals = 0 }: {
  label: string; value: number; onCommit: (v: number) => void;
  step?: number; min?: number; max?: number; decimals?: number;
}) {
  const fmt = (v: number) => Number(v.toFixed(decimals)).toString();
  const [txt, setTxt] = useState(fmt(value));
  const [focus, setFocus] = useState(false);
  useEffect(() => { if (!focus) setTxt(fmt(value)); }, [value, focus]);
  const commit = (v: number) => {
    if (!isFinite(v)) return;
    let n = v;
    if (min !== undefined) n = Math.max(min, n);
    if (max !== undefined) n = Math.min(max, n);
    onCommit(n);
  };
  return (
    <View style={s.wrap}>
      <Text style={s.label}>{label}</Text>
      <View style={s.row}>
        <Pressable style={s.btn} onPress={() => commit(value - step)}><Text style={s.btnT}>−</Text></Pressable>
        <TextInput style={s.input} value={txt} keyboardType="numeric" selectTextOnFocus
          onFocus={() => setFocus(true)} onChangeText={setTxt}
          onEndEditing={() => { setFocus(false); const n = parseFloat(txt.replace(',', '.')); if (isFinite(n)) commit(n); else setTxt(fmt(value)); }} />
        <Pressable style={s.btn} onPress={() => commit(value + step)}><Text style={s.btnT}>+</Text></Pressable>
      </View>
    </View>
  );
}

export function CommitText({ label, value, onCommit, multiline }: {
  label: string; value: string; onCommit: (v: string) => void; multiline?: boolean;
}) {
  const [txt, setTxt] = useState(value);
  useEffect(() => { setTxt(value); }, [value]);
  return (
    <View style={{ marginBottom: 8 }}>
      <Text style={s.label}>{label}</Text>
      <TextInput style={[s.input, s.full]} value={txt} multiline={multiline} onChangeText={setTxt}
        onEndEditing={() => { if (txt !== value) onCommit(txt); }} />
    </View>
  );
}

const s = StyleSheet.create({
  wrap: { flex: 1 },
  label: { color: colors.textDim, fontSize: 11, marginBottom: 3 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  btn: { width: 30, height: 34, borderRadius: radius.sm, backgroundColor: colors.panel, alignItems: 'center', justifyContent: 'center' },
  btnT: { color: colors.text, fontSize: 18, fontWeight: '700' },
  input: { flex: 1, height: 34, backgroundColor: colors.panel, color: colors.text, borderRadius: radius.sm, textAlign: 'center', paddingVertical: 0, paddingHorizontal: 6 },
  full: { textAlign: 'left', minHeight: 36 },
});
