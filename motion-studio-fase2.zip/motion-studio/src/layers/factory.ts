import { Layer, MediaAsset, Project, defaultTransform, uid } from '@/projects/schema';

export type NewLayerKind = 'solid' | 'text' | 'rect' | 'ellipse' | 'image';

const NAMES: Record<NewLayerKind, string> = {
  solid: 'Sólido', text: 'Texto', rect: 'Retângulo', ellipse: 'Elipse', image: 'Imagem',
};

export function makeLayer(
  kind: NewLayerKind, p: Project, time: number,
  img?: { asset: MediaAsset; w: number; h: number },
): Layer {
  const { width: W, height: H, duration } = p.composition;
  const start = Math.min(time, Math.max(0, duration - 0.5));
  const dur = Math.max(0.5, Math.min(5, duration - start));
  const base: Layer = {
    id: uid(), type: 'solid', name: NAMES[kind], startTime: start, duration: dur, inPoint: 0,
    locked: false, hidden: false, transform: defaultTransform(W, H), effects: [], masks: [],
  };
  const side = Math.round(Math.min(W, H) * 0.4);
  switch (kind) {
    case 'solid': return { ...base, type: 'solid', content: { color: '#8B5CF6' } };
    case 'text': return { ...base, type: 'text', content: { text: 'Texto', fontSize: Math.round(H * 0.08), color: '#FFFFFF' } };
    case 'rect': return { ...base, type: 'shape', content: { shape: 'rect', width: side, height: side, color: '#3B82F6' } };
    case 'ellipse': return { ...base, type: 'shape', content: { shape: 'ellipse', width: side, height: side, color: '#F0506E' } };
    case 'image': {
      const a = img!;
      const k = Math.min((W * 0.8) / a.w, (H * 0.8) / a.h, 1);
      return { ...base, type: 'image', name: a.asset.name, mediaId: a.asset.id, content: { width: Math.round(a.w * k), height: Math.round(a.h * k) } };
    }
  }
}
