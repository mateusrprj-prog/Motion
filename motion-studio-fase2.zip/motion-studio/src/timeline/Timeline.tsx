import React, { useEffect, useMemo, useRef, useState } from 'react';
import { PanResponder, ScrollView, StyleSheet, Text, View, LayoutChangeEvent, NativeScrollEvent, NativeSyntheticEvent } from 'react-native';
import { Layer } from '@/projects/schema';
import { useEditorStore } from '@/editor/useEditorStore';
import { updateLayer } from '@/editor/commands';
import { colors } from '@/theme';

const ROW_H = 40;
const RULER_H = 28;
const COLORS: Record<string, string> = { solid: '#8B5CF6', text: '#3B82F6', shape: '#14B8A6', image: '#F59E0B' };

type Mode = 'move' | 'left' | 'right';

function Clip({ layer, selected, ppsRef, setLock }: {
  layer: Layer; selected: boolean; ppsRef: React.MutableRefObject<number>; setLock: (b: boolean) => void;
}) {
  const base = useRef({ start: 0, dur: 0, inPoint: 0 });
  const active = useRef(false);

  const make = (mode: Mode) => PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderTerminationRequest: () => false,
    onPanResponderGrant: () => {
      setLock(true);
      const st = useEditorStore.getState();
      st.select(layer.id);
      const l = st.project?.composition.layers.find((x) => x.id === layer.id);
      active.current = !!l && !l.locked;
      if (l && active.current) {
        base.current = { start: l.startTime, dur: l.duration, inPoint: l.inPoint };
        st.beginGesture();
      }
    },
    onPanResponderMove: (_, g) => {
      if (!active.current) return;
      const st = useEditorStore.getState();
      const comp = st.project!.composition;
      const fps = comp.fps, D = comp.duration;
      const snap = (v: number) => Math.round(v * fps) / fps;
      const minDur = 2 / fps;
      const dt = g.dx / ppsRef.current;
      const b = base.current;
      if (mode === 'move') {
        const s = Math.min(Math.max(0, snap(b.start + dt)), Math.max(0, D - b.dur));
        st.transient(updateLayer(layer.id, { startTime: s }));
      } else if (mode === 'left') {
        const ns = Math.min(Math.max(0, snap(b.start + dt)), b.start + b.dur - minDur);
        const delta = ns - b.start;
        st.transient(updateLayer(layer.id, { startTime: ns, duration: b.dur - delta, inPoint: Math.max(0, b.inPoint + delta) }));
      } else {
        const nd = Math.min(Math.max(minDur, snap(b.dur + dt)), D - b.start);
        st.transient(updateLayer(layer.id, { duration: nd }));
      }
    },
    onPanResponderRelease: () => { if (active.current) useEditorStore.getState().endGesture(); active.current = false; setLock(false); },
    onPanResponderTerminate: () => { if (active.current) useEditorStore.getState().endGesture(); active.current = false; setLock(false); },
  });
  const pr = useMemo(() => ({ move: make('move'), left: make('left'), right: make('right') }), [layer.id]);

  const pps = ppsRef.current;
  const w = Math.max(28, layer.duration * pps);
  return (
    <View {...pr.move.panHandlers} style={[styles.clip, {
      left: layer.startTime * pps, width: w, backgroundColor: COLORS[layer.type] ?? '#666',
      opacity: layer.hidden ? 0.35 : 1, borderColor: selected ? '#FFFFFF' : 'transparent',
    }]}>
      <Text numberOfLines={1} style={styles.clipText} pointerEvents="none">{layer.name}{layer.locked ? ' (bloqueada)' : ''}</Text>
      <View {...pr.left.panHandlers} style={[styles.handle, { left: 0 }]}><View style={styles.grip} pointerEvents="none" /></View>
      <View {...pr.right.panHandlers} style={[styles.handle, { right: 0 }]}><View style={styles.grip} pointerEvents="none" /></View>
    </View>
  );
}

export function Timeline() {
  const project = useEditorStore((s) => s.project);
  const time = useEditorStore((s) => s.time);
  const playing = useEditorStore((s) => s.playing);
  const pps = useEditorStore((s) => s.pxPerSec);
  const selectedId = useEditorStore((s) => s.selectedId);
  const [lock, setLock] = useState(false);
  const [viewW, setViewW] = useState(0);
  const scrollX = useRef(0);
  const scroller = useRef<ScrollView>(null);
  const ppsRef = useRef(pps);
  ppsRef.current = pps;

  const rulerPR = useMemo(() => {
    const seek = (x: number) => useEditorStore.getState().setTime(x / ppsRef.current);
    return PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderTerminationRequest: () => false,
      onPanResponderGrant: (e) => { setLock(true); seek(e.nativeEvent.locationX); },
      onPanResponderMove: (e) => seek(e.nativeEvent.locationX),
      onPanResponderRelease: () => setLock(false),
      onPanResponderTerminate: () => setLock(false),
    });
  }, []);

  useEffect(() => {
    if (!playing) return;
    const x = time * pps;
    if (x > scrollX.current + viewW - 40 || x < scrollX.current) scroller.current?.scrollTo({ x: Math.max(0, x - 40), animated: false });
  }, [time, playing, pps, viewW]);

  if (!project) return null;
  const D = project.composition.duration;
  const contentW = Math.max(viewW, D * pps + 60);
  const steps = [0.1, 0.2, 0.5, 1, 2, 5, 10, 30];
  const step = steps.find((s) => s * pps >= 70) ?? 30;
  const ticks: number[] = [];
  for (let t = 0; t <= D + 1e-6; t += step) ticks.push(Number(t.toFixed(2)));
  const rows = [...project.composition.layers].reverse();

  return (
    <ScrollView ref={scroller} horizontal scrollEnabled={!lock} style={styles.root}
      onLayout={(e: LayoutChangeEvent) => setViewW(e.nativeEvent.layout.width)}
      onScroll={(e: NativeSyntheticEvent<NativeScrollEvent>) => { scrollX.current = e.nativeEvent.contentOffset.x; }}
      scrollEventThrottle={32} contentContainerStyle={{ width: contentW, flexGrow: 1 }}>
      <View style={{ flex: 1 }}>
        <View {...rulerPR.panHandlers} style={styles.ruler}>
          <View pointerEvents="none" style={StyleSheet.absoluteFill}>
            {ticks.map((t) => (
              <View key={t} style={[styles.tick, { left: t * pps }]}>
                <Text style={styles.tickText}>{step < 1 ? t.toFixed(1) : t}s</Text>
              </View>
            ))}
            <View style={[styles.endMark, { left: D * pps }]} />
          </View>
        </View>
        <ScrollView scrollEnabled={!lock} nestedScrollEnabled style={{ flex: 1 }}>
          {rows.length === 0 && <Text style={styles.empty}>Sem camadas. Use a aba “Adicionar”.</Text>}
          {rows.map((l) => (
            <View key={l.id} style={styles.row}>
              <Clip layer={l} selected={l.id === selectedId} ppsRef={ppsRef} setLock={setLock} />
            </View>
          ))}
        </ScrollView>
        <View pointerEvents="none" style={[styles.playhead, { left: time * pps - 1 }]} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.surface },
  ruler: { height: RULER_H, backgroundColor: colors.panel, borderBottomWidth: 1, borderBottomColor: colors.border },
  tick: { position: 'absolute', top: 0, bottom: 0, borderLeftWidth: 1, borderLeftColor: colors.border, paddingLeft: 3 },
  tickText: { color: colors.textDim, fontSize: 10, marginTop: 6 },
  endMark: { position: 'absolute', top: 0, bottom: 0, width: 2, backgroundColor: colors.danger },
  row: { height: ROW_H, borderBottomWidth: 1, borderBottomColor: '#20202c' },
  clip: { position: 'absolute', top: 3, height: ROW_H - 6, borderRadius: 6, borderWidth: 2, justifyContent: 'center', paddingHorizontal: 16, overflow: 'hidden' },
  clipText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  handle: { position: 'absolute', top: 0, bottom: 0, width: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: '#0006' },
  grip: { width: 3, height: 16, borderRadius: 2, backgroundColor: '#fff' },
  playhead: { position: 'absolute', top: 0, bottom: 0, width: 2, backgroundColor: '#FFFFFF' },
  empty: { color: colors.textDim, padding: 16 },
});
