import React, { useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { loadProject, saveProject } from '@/projects/storage';
import { uid } from '@/projects/schema';
import { useEditorStore } from '@/editor/useEditorStore';
import { splitLayer } from '@/editor/commands';
import { Viewer } from '@/renderer/Viewer';
import { Timeline } from '@/timeline/Timeline';
import { AddPanel } from '@/editor/AddPanel';
import { LayersPanel } from '@/editor/LayersPanel';
import { PropertiesPanel } from '@/editor/PropertiesPanel';
import { colors, radius, space } from '@/theme';

type Tab = 'add' | 'layers' | 'props';
const pad = (n: number) => String(n).padStart(2, '0');
const fmtTime = (t: number, fps: number) => `${pad(Math.floor(t / 60))}:${pad(Math.floor(t % 60))}:${pad(Math.floor((t % 1) * fps))}`;

export default function Editor() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { height: winH } = useWindowDimensions();
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('add');

  const project = useEditorStore((s) => s.project);
  const dirty = useEditorStore((s) => s.dirty);
  const time = useEditorStore((s) => s.time);
  const playing = useEditorStore((s) => s.playing);
  const canUndo = useEditorStore((s) => s.past.length > 0);
  const canRedo = useEditorStore((s) => s.future.length > 0);
  const selectedId = useEditorStore((s) => s.selectedId);

  useEffect(() => {
    loadProject(String(id)).then((p) => useEditorStore.getState().load(p)).catch((e) => setError(String(e?.message ?? e)));
    return () => useEditorStore.getState().reset();
  }, [id]);

  // Autosave: 1,2 s após a última alteração.
  const saving = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (!project || !dirty) return;
    if (saving.current) clearTimeout(saving.current);
    saving.current = setTimeout(async () => {
      try { await saveProject(project); useEditorStore.getState().markSaved(project); } catch (e: any) { setError('Falha ao salvar: ' + String(e?.message ?? e)); }
    }, 1200);
    return () => { if (saving.current) clearTimeout(saving.current); };
  }, [project, dirty]);

  const goBack = async () => {
    const st = useEditorStore.getState();
    st.pause();
    if (st.project && st.dirty) { try { await saveProject(st.project); } catch { /* mantém aberto */ } }
    router.back();
  };

  if (error && !project) return <View style={[s.root, { paddingTop: insets.top + 16 }]}><Pressable onPress={() => router.back()}><Text style={s.back}>Voltar</Text></Pressable><Text style={s.err}>{error}</Text></View>;
  if (!project) return <View style={[s.root, { paddingTop: insets.top + 16 }]}><Text style={s.dim}>Abrindo projeto…</Text></View>;

  const st = useEditorStore.getState();
  const fps = project.composition.fps;

  return (
    <View style={[s.root, { paddingTop: insets.top, paddingBottom: insets.bottom }]}>
      <View style={s.header}>
        <Pressable onPress={goBack}><Text style={s.back}>Voltar</Text></Pressable>
        <Text style={s.title} numberOfLines={1}>{project.name}</Text>
        <Text style={s.dim}>{dirty ? 'Salvando…' : 'Salvo'}</Text>
      </View>

      <Viewer height={Math.round(winH * 0.34)} />

      <View style={s.toolbar}>
        <Btn t={playing ? 'Pausar' : 'Play'} on={() => (playing ? st.pause() : st.play())} primary />
        <Text style={s.time}>{fmtTime(time, fps)}</Text>
        <Btn t="Desfazer" on={st.undo} off={!canUndo} />
        <Btn t="Refazer" on={st.redo} off={!canRedo} />
        <Btn t="Cortar" off={!selectedId} on={() => { if (selectedId) st.apply(splitLayer(selectedId, st.time, uid())); }} />
        <Btn t="−" on={() => st.zoom(1 / 1.5)} />
        <Btn t="+" on={() => st.zoom(1.5)} />
      </View>

      <Timeline />

      <View style={s.panel}>
        <View style={s.tabs}>
          {([['add', 'Adicionar'], ['layers', 'Camadas'], ['props', 'Propriedades']] as [Tab, string][]).map(([k, l]) => (
            <Pressable key={k} onPress={() => setTab(k)} style={[s.tab, tab === k && s.tabOn]}><Text style={s.tabT}>{l}</Text></Pressable>
          ))}
        </View>
        {tab === 'add' && <AddPanel />}
        {tab === 'layers' && <LayersPanel />}
        {tab === 'props' && <PropertiesPanel />}
      </View>
      {error ? <Text style={s.err}>{error}</Text> : null}
    </View>
  );
}

const Btn = ({ t, on, off, primary }: { t: string; on: () => void; off?: boolean; primary?: boolean }) => (
  <Pressable disabled={off} onPress={on} style={[s.btn, primary && { backgroundColor: colors.purple, borderColor: colors.purple }, off && { opacity: 0.35 }]}>
    <Text style={s.btnT}>{t}</Text>
  </Pressable>
);

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { flexDirection: 'row', alignItems: 'center', gap: space.md, paddingHorizontal: space.lg, height: 44 },
  back: { color: colors.blue, fontSize: 15 },
  title: { flex: 1, color: colors.text, fontWeight: '700', fontSize: 16 },
  dim: { color: colors.textDim, fontSize: 12 },
  err: { color: colors.danger, padding: 8 },
  toolbar: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 8, height: 46, backgroundColor: colors.surface, borderTopWidth: 1, borderBottomWidth: 1, borderColor: colors.border },
  time: { color: colors.text, fontVariant: ['tabular-nums'], fontSize: 12, minWidth: 64 },
  btn: { paddingVertical: 7, paddingHorizontal: 9, borderRadius: radius.sm, backgroundColor: colors.panel, borderWidth: 1, borderColor: colors.border },
  btnT: { color: colors.text, fontSize: 12, fontWeight: '600' },
  panel: { height: 250, backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border },
  tabs: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: colors.border },
  tab: { flex: 1, paddingVertical: 10, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabOn: { borderBottomColor: colors.purple },
  tabT: { color: colors.text, fontWeight: '600', fontSize: 13 },
});
