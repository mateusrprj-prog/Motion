import { Platform } from 'react-native';
import { matchFont, SkFont } from '@shopify/react-native-skia';

const cache = new Map<number, SkFont>();
export function getFont(size: number): SkFont {
  const s = Math.max(4, Math.round(size));
  let f = cache.get(s);
  if (!f) {
    f = matchFont({ fontFamily: Platform.select({ ios: 'Helvetica', default: 'sans-serif' }), fontSize: s, fontWeight: 'bold' });
    cache.set(s, f);
  }
  return f;
}
export const measureText = (text: string, size: number) => getFont(size).getTextWidth(text || ' ');
