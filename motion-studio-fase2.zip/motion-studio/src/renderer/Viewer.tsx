import React, { useMemo, useRef, useState } from 'react';
import { PanResponder, StyleSheet, View } from 'react-native';
import {
  Canvas, Group, Oval, Rect, Image as SkImage, Text as SkText, rect, useImage,
} from '@shopify/react-native-skia';
import { useEditorStore } from '@/editor/useEditorStore';
import { moveLayerTo } from '@/editor/commands';
import { RenderItem, evaluateFrame, hitTest } from './evaluate';
import { getFont } from './fonts';

function transformOf(it: RenderItem) {
  return [{ translateX: it.x }, { translateY: it.y }, { rotate: it.rot }, { scaleX: it.sx }, { scaleY: it.sy }];
}

function ImageNode({ it, x, y }: { it: RenderItem; x: number; y: number }) {
  const img = useImage(it.uri ?? null);
  if (!img) return null;
  return <SkImage image={img} x={x} y={y} width={it.w} height={it.h} fit="fill" />;
}

function LayerNode({ it }: { it: RenderItem }) {
  const c = it.layer.content ?? {};
  const x = -it.w / 2 - it.ax, y = -it.h / 2 - it.ay;
  const color = c.color ?? '#FFFFFF';
  return (
    <Group transform={transformOf(it)} opacity={it.opacity}>
      {it.layer.type === 'solid' && <Rect x={x} y={y} width={it.w} height={it.h} color={color} />}
      {it.layer.type === 'shape' && c.shape === 'ellipse' && <Oval x={x} y={y} width={it.w} height={it.h} color={color} />}
      {it.layer.type === 'shape' && c.shape !== 'ellipse' && <Rect x={x} y={y} width={it.w} height={it.h} color={color} />}
      {it.layer.type === 'text' && <SkText x={x} y={y + it.h * 0.8} text={c.text ?? ''} font={getFont(c.fontSize ?? 64)} color={color} />}
      {it.layer.type === 'image' && <ImageNode it={it} x={x} y={y} />}
    </Group>
  );
}

export function Viewer({ height }: { height: number }) {
  const project = useEditorStore((s) => s.project)!;
  const time = useEditorStore((s) => s.time);
  const selectedId = useEditorStore((s) => s.selectedId);
  const [size, setSize] = useState({ w: 0, h: 0 });
  const comp = project.composition;

  const items = useMemo(() => evaluateFrame(project, time), [project, time]);
  const scale = size.w ? Math.min((size.w * 0.94) / comp.width, (size.h * 0.94) / comp.height) : 1;
  const offX = (size.w - comp.width * scale) / 2;
  const offY = (size.h - comp.height * scale) / 2;

  const latest = useRef({ items, scale, offX, offY });
  latest.current = { items, scale, offX, offY };
  const drag = useRef<{ id: string; x: number; y: number } | null>(null);

  const responder = useMemo(() => PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onPanResponderTerminationRequest: () => false,
    onPanResponderGrant: (e) => {
      const L = latest.current;
      const st = useEditorStore.getState();
      if (st.playing) st.pause();
      const cx = (e.nativeEvent.locationX - L.offX) / L.scale;
      const cy = (e.nativeEvent.locationY - L.offY) / L.scale;
      const id = hitTest(L.items, cx, cy);
      st.select(id);
      drag.current = null;
      if (!id) return;
      const layer = st.project?.composition.layers.find((l) => l.id === id);
      if (layer && !layer.locked) {
        st.beginGesture();
        drag.current = { id, x: layer.transform.positionX.value, y: layer.transform.positionY.value };
      }
    },
    onPanResponderMove: (_, g) => {
      const d = drag.current;
      if (!d) return;
      const s = latest.current.scale || 1;
      useEditorStore.getState().transient(moveLayerTo(d.id, d.x + g.dx / s, d.y + g.dy / s));
    },
    onPanResponderRelease: () => { if (drag.current) useEditorStore.getState().endGesture(); drag.current = null; },
    onPanResponderTerminate: () => { if (drag.current) useEditorStore.getState().endGesture(); drag.current = null; },
  }), []);

  const sel = items.find((i) => i.layer.id === selectedId);

  return (
    <View style={[styles.box, { height }]} onLayout={(e) => setSize({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height })} {...responder.panHandlers}>
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        <Canvas style={{ flex: 1 }}>
          <Group transform={[{ translateX: offX }, { translateY: offY }, { scale }]}>
            <Group clip={rect(0, 0, comp.width, comp.height)}>
              <Rect x={0} y={0} width={comp.width} height={comp.height} color={comp.backgroundColor} />
              {items.map((it) => <LayerNode key={it.layer.id} it={it} />)}
            </Group>
            {sel && (
              <Group transform={transformOf(sel)}>
                <Rect x={-sel.w / 2 - sel.ax} y={-sel.h / 2 - sel.ay} width={sel.w} height={sel.h}
                  style="stroke" strokeWidth={2.5 / scale} color="#8B5CF6" />
              </Group>
            )}
          </Group>
        </Canvas>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({ box: { backgroundColor: '#050508', width: '100%' } });
