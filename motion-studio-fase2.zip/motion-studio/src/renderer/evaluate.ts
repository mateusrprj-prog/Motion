import { Layer, Project } from '@/projects/schema';
import { measureText } from './fonts';

// Avalia a composição no tempo t. Preview e exportação (Fase 6) usam esta mesma função.
export interface RenderItem {
  layer: Layer;
  x: number; y: number;      // centro da camada na composição (px)
  sx: number; sy: number;    // escala (1 = 100%)
  rot: number;               // radianos
  opacity: number;           // 0..1
  w: number; h: number;      // tamanho antes da escala
  ax: number; ay: number;    // deslocamento da âncora
  uri?: string;
}

export function layerSize(l: Layer, p: Project): { w: number; h: number } | null {
  const c = l.content ?? {};
  switch (l.type) {
    case 'solid': return { w: p.composition.width, h: p.composition.height };
    case 'text': { const fs = c.fontSize ?? 64; return { w: measureText(c.text ?? '', fs), h: fs * 1.25 }; }
    case 'shape':
    case 'image': return { w: c.width ?? 100, h: c.height ?? 100 };
    default: return null; // vídeo, áudio, pré-comp, câmera: fases futuras
  }
}

export function evaluateFrame(p: Project, t: number): RenderItem[] {
  const out: RenderItem[] = [];
  for (const l of p.composition.layers) {
    if (l.hidden || t < l.startTime || t >= l.startTime + l.duration) continue;
    const size = layerSize(l, p);
    if (!size) continue;
    const tr = l.transform;
    out.push({
      layer: l, x: tr.positionX.value, y: tr.positionY.value,
      sx: tr.scaleX.value / 100, sy: tr.scaleY.value / 100,
      rot: (tr.rotation.value * Math.PI) / 180,
      opacity: Math.max(0, Math.min(1, tr.opacity.value / 100)),
      w: size.w, h: size.h, ax: tr.anchorX.value, ay: tr.anchorY.value,
      uri: l.mediaId ? p.media.find((m) => m.id === l.mediaId)?.uri : undefined,
    });
  }
  return out;
}

export function hitTest(items: RenderItem[], px: number, py: number): string | null {
  for (let i = items.length - 1; i >= 0; i--) {
    const it = items[i];
    if (!it.sx || !it.sy) continue;
    const dx = px - it.x, dy = py - it.y;
    const c = Math.cos(it.rot), s = Math.sin(it.rot);
    const lx = (dx * c + dy * s) / it.sx, ly = (-dx * s + dy * c) / it.sy;
    if (lx >= -it.w / 2 - it.ax && lx <= it.w / 2 - it.ax && ly >= -it.h / 2 - it.ay && ly <= it.h / 2 - it.ay) return it.layer.id;
  }
  return null;
}
