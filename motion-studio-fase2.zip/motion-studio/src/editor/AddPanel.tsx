import React, { useEffect, useState } from 'react';
import { Alert, Image, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { MediaAsset } from '@/projects/schema';
import { loadLibrary, importMedia } from '@/media/import';
import { makeLayer, NewLayerKind } from '@/layers/factory';
import { addLayer } from './commands';
import { useEditorStore } from './useEditorStore';
import { colors, radius, space } from '@/theme';

const KINDS: { kind: NewLayerKind; label: string }[] = [
  { kind: 'text', label: 'Texto' }, { kind: 'rect', label: 'Retângulo' },
  { kind: 'ellipse', label: 'Elipse' }, { kind: 'solid', label: 'Sólido' },
];

function imageSize(uri: string): Promise<{ w: number; h: number }> {
  return new Promise((res, rej) => Image.getSize(uri, (w, h) => res({ w, h }), rej));
}

export function AddPanel() {
  const [media, setMedia] = useState<MediaAsset[]>([]);
  useEffect(() => { loadLibrary().then(setMedia); }, []);

  const add = (kind: NewLayerKind) => {
    const st = useEditorStore.getState();
    if (!st.project) return;
    const layer = makeLayer(kind, st.project, st.time);
    st.apply(addLayer(layer));
    st.select(layer.id);
  };
  const addImage = async (a: MediaAsset) => {
    const st = useEditorStore.getState();
    if (!st.project) return;
    try {
      const { w, h } = await imageSize(a.uri);
      const layer = makeLayer('image', st.project, st.time, { asset: a, w, h });
      st.apply(addLayer(layer, a));
      st.select(layer.id);
    } catch { Alert.alert('Erro', 'Não foi possível abrir esta imagem.'); }
  };
  const doImport = async () => {
    try {
      const { rejected } = await importMedia();
      if (rejected.length) Alert.alert('Formato não suportado', rejected.join('\n'));
      setMedia(await loadLibrary());
    } catch (e: any) { Alert.alert('Erro ao importar', String(e?.message ?? e)); }
  };
  const images = media.filter((m) => m.kind === 'image');

  return (
    <ScrollView contentContainerStyle={{ padding: space.md }}>
      <Text style={s.h}>Camadas novas (entram no ponto atual)</Text>
      <View style={s.row}>
        {KINDS.map((k) => (
          <Pressable key={k.kind} style={s.btn} onPress={() => add(k.kind)}><Text style={s.btnT}>{k.label}</Text></Pressable>
        ))}
      </View>
      <Text style={s.h}>Imagens importadas</Text>
      <View style={s.row}>
        {images.map((m) => (
          <Pressable key={m.id} onPress={() => addImage(m)}>
            <Image source={{ uri: m.uri }} style={s.thumb} />
          </Pressable>
        ))}
        <Pressable style={[s.btn, { alignSelf: 'center' }]} onPress={doImport}><Text style={s.btnT}>Importar</Text></Pressable>
      </View>
      <Text style={s.note}>Vídeo e áudio entram na Fase 6.</Text>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  h: { color: colors.text, fontWeight: '700', marginBottom: 8, marginTop: 4 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  btn: { backgroundColor: colors.panel, borderWidth: 1, borderColor: colors.purple, paddingVertical: 10, paddingHorizontal: 14, borderRadius: radius.sm },
  btnT: { color: colors.text, fontWeight: '600' },
  thumb: { width: 64, height: 64, borderRadius: radius.sm, backgroundColor: colors.panel },
  note: { color: colors.textDim, fontSize: 12 },
});
