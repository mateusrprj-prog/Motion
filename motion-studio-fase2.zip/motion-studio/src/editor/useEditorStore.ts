import { create } from 'zustand';
import { Project } from '@/projects/schema';
import { Cmd } from './commands';

const MAX_HISTORY = 100;
let raf = 0;

interface EditorState {
  project: Project | null;
  dirty: boolean;
  time: number;
  playing: boolean;
  selectedId: string | null;
  pxPerSec: number;
  past: Project[];
  future: Project[];
  gestureBase: Project | null;
  load: (p: Project) => void;
  reset: () => void;
  apply: (cmd: Cmd) => void;
  beginGesture: () => void;
  transient: (cmd: Cmd) => void;
  endGesture: () => void;
  undo: () => void;
  redo: () => void;
  markSaved: (p: Project) => void;
  setTime: (t: number) => void;
  play: () => void;
  pause: () => void;
  select: (id: string | null) => void;
  zoom: (factor: number) => void;
}

const validSel = (p: Project, id: string | null) => (id && p.composition.layers.some((l) => l.id === id) ? id : null);

export const useEditorStore = create<EditorState>((set, get) => ({
  project: null, dirty: false, time: 0, playing: false, selectedId: null, pxPerSec: 80,
  past: [], future: [], gestureBase: null,

  load: (p) => set({ project: p, dirty: false, time: 0, playing: false, selectedId: null, past: [], future: [], gestureBase: null }),
  reset: () => { cancelAnimationFrame(raf); set({ project: null, dirty: false, time: 0, playing: false, selectedId: null, past: [], future: [], gestureBase: null }); },

  apply: (cmd) => {
    const { project, past } = get();
    if (!project) return;
    const next = cmd(project);
    if (next === project) return;
    set({ project: next, past: [...past.slice(-(MAX_HISTORY - 1)), project], future: [], dirty: true, selectedId: validSel(next, get().selectedId) });
  },
  beginGesture: () => set({ gestureBase: get().project }),
  transient: (cmd) => {
    const { project } = get();
    if (!project) return;
    const next = cmd(project);
    if (next !== project) set({ project: next, dirty: true });
  },
  endGesture: () => {
    const { gestureBase, project, past } = get();
    if (gestureBase && project && project !== gestureBase) {
      set({ past: [...past.slice(-(MAX_HISTORY - 1)), gestureBase], future: [] });
    }
    set({ gestureBase: null });
  },
  undo: () => {
    const { past, future, project } = get();
    if (!project || !past.length) return;
    const prev = past[past.length - 1];
    set({ project: prev, past: past.slice(0, -1), future: [project, ...future], dirty: true, selectedId: validSel(prev, get().selectedId) });
  },
  redo: () => {
    const { past, future, project } = get();
    if (!project || !future.length) return;
    const nxt = future[0];
    set({ project: nxt, past: [...past, project], future: future.slice(1), dirty: true, selectedId: validSel(nxt, get().selectedId) });
  },
  markSaved: (p) => { if (get().project === p) set({ dirty: false }); },

  setTime: (t) => {
    const { project } = get();
    if (!project) return;
    if (get().playing) get().pause();
    set({ time: Math.max(0, Math.min(project.composition.duration, t)) });
  },
  play: () => {
    const s = get();
    if (!s.project || s.playing) return;
    const dur = s.project.composition.duration;
    const base = s.time >= dur - 0.001 ? 0 : s.time;
    const t0 = performance.now();
    set({ playing: true, time: base });
    const loop = () => {
      const d = get().project?.composition.duration ?? dur;
      const t = base + (performance.now() - t0) / 1000;
      if (t >= d) { set({ time: d, playing: false }); return; }
      set({ time: t });
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
  },
  pause: () => { cancelAnimationFrame(raf); set({ playing: false }); },
  select: (id) => set({ selectedId: id }),
  zoom: (f) => set({ pxPerSec: Math.max(20, Math.min(600, get().pxPerSec * f)) }),
}));
