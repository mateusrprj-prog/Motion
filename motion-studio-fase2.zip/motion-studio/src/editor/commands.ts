import { Layer, LayerContent, MediaAsset, Project, Transform, uid } from '@/projects/schema';

// Comando = função pura (Project -> Project). Desfazer/refazer usa snapshots imutáveis.
// A IA (Fase 8) emitirá estes mesmos comandos.
export type Cmd = (p: Project) => Project;

const mapLayer = (p: Project, id: string, fn: (l: Layer) => Layer): Project => {
  let changed = false;
  const layers = p.composition.layers.map((l) => {
    if (l.id !== id) return l;
    changed = true;
    return fn(l);
  });
  return changed ? { ...p, composition: { ...p.composition, layers } } : p;
};

export const addLayer = (layer: Layer, asset?: MediaAsset): Cmd => (p) => ({
  ...p,
  media: asset && !p.media.some((m) => m.id === asset.id) ? [...p.media, asset] : p.media,
  composition: { ...p.composition, layers: [...p.composition.layers, layer] },
});

export const removeLayer = (id: string): Cmd => (p) => ({
  ...p, composition: { ...p.composition, layers: p.composition.layers.filter((l) => l.id !== id) },
});

export const duplicateLayer = (id: string, newId: string): Cmd => (p) => {
  const layers = p.composition.layers;
  const i = layers.findIndex((l) => l.id === id);
  if (i < 0) return p;
  const copy: Layer = JSON.parse(JSON.stringify(layers[i]));
  copy.id = newId; copy.name = layers[i].name + ' cópia';
  const next = [...layers]; next.splice(i + 1, 0, copy);
  return { ...p, composition: { ...p.composition, layers: next } };
};

// dir = 1 sobe (mais à frente), -1 desce
export const reorderLayer = (id: string, dir: 1 | -1): Cmd => (p) => {
  const layers = [...p.composition.layers];
  const i = layers.findIndex((l) => l.id === id);
  const j = i + dir;
  if (i < 0 || j < 0 || j >= layers.length) return p;
  [layers[i], layers[j]] = [layers[j], layers[i]];
  return { ...p, composition: { ...p.composition, layers } };
};

export const updateLayer = (id: string, patch: Partial<Layer>): Cmd => (p) => mapLayer(p, id, (l) => ({ ...l, ...patch }));

export const updateContent = (id: string, patch: Partial<LayerContent>): Cmd => (p) =>
  mapLayer(p, id, (l) => ({ ...l, content: { ...l.content, ...patch } }));

export const setTransformValue = (id: string, key: keyof Transform, value: number): Cmd => (p) =>
  mapLayer(p, id, (l) => ({ ...l, transform: { ...l.transform, [key]: { ...l.transform[key], value } } }));

export const moveLayerTo = (id: string, x: number, y: number): Cmd => (p) =>
  mapLayer(p, id, (l) => ({
    ...l,
    transform: {
      ...l.transform,
      positionX: { ...l.transform.positionX, value: x },
      positionY: { ...l.transform.positionY, value: y },
    },
  }));

// Corta a camada no tempo t: a original termina em t e uma nova começa em t.
export const splitLayer = (id: string, t: number, newId: string = uid()): Cmd => (p) => {
  const layers = p.composition.layers;
  const i = layers.findIndex((l) => l.id === id);
  if (i < 0) return p;
  const l = layers[i];
  const end = l.startTime + l.duration;
  if (t <= l.startTime + 0.01 || t >= end - 0.01) return p;
  const first: Layer = { ...l, duration: t - l.startTime };
  const second: Layer = JSON.parse(JSON.stringify(l));
  second.id = newId; second.startTime = t; second.duration = end - t; second.inPoint = l.inPoint + (t - l.startTime);
  const next = [...layers]; next.splice(i, 1, first, second);
  return { ...p, composition: { ...p.composition, layers: next } };
};

export const setComposition = (patch: Partial<Project['composition']>): Cmd => (p) => ({
  ...p, composition: { ...p.composition, ...patch },
});

export const renameProject = (name: string): Cmd => (p) => ({ ...p, name });
