import React from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { uid } from '@/projects/schema';
import { useEditorStore } from './useEditorStore';
import { duplicateLayer, removeLayer, reorderLayer, updateLayer } from './commands';
import { colors, radius } from '@/theme';

const TYPE: Record<string, string> = { solid: 'Sólido', text: 'Texto', shape: 'Forma', image: 'Imagem' };

export function LayersPanel() {
  const project = useEditorStore((s) => s.project)!;
  const selectedId = useEditorStore((s) => s.selectedId);
  const { apply, select } = useEditorStore.getState();
  const layers = [...project.composition.layers].reverse();

  if (!layers.length) return <Text style={s.empty}>Nenhuma camada ainda.</Text>;
  return (
    <FlatList data={layers} keyExtractor={(l) => l.id} contentContainerStyle={{ padding: 10, gap: 6 }}
      renderItem={({ item: l }) => {
        const sel = l.id === selectedId;
        return (
          <Pressable onPress={() => select(l.id)} style={[s.row, sel && s.rowSel]}>
            <Text style={s.name} numberOfLines={1}>{l.name}  <Text style={s.type}>{TYPE[l.type] ?? l.type}{l.hidden ? ' · oculta' : ''}{l.locked ? ' · bloqueada' : ''}</Text></Text>
            {sel && (
              <View style={s.actions}>
                <Chip t={l.hidden ? 'Mostrar' : 'Ocultar'} on={() => apply(updateLayer(l.id, { hidden: !l.hidden }))} />
                <Chip t={l.locked ? 'Liberar' : 'Bloquear'} on={() => apply(updateLayer(l.id, { locked: !l.locked }))} />
                <Chip t="Subir" on={() => apply(reorderLayer(l.id, 1))} />
                <Chip t="Descer" on={() => apply(reorderLayer(l.id, -1))} />
                <Chip t="Duplicar" on={() => { const id = uid(); apply(duplicateLayer(l.id, id)); select(id); }} />
                <Chip t="Excluir" danger on={() => apply(removeLayer(l.id))} />
              </View>
            )}
          </Pressable>
        );
      }} />
  );
}

const Chip = ({ t, on, danger }: { t: string; on: () => void; danger?: boolean }) => (
  <Pressable onPress={on} style={[s.chip, danger && { borderColor: colors.danger }]}><Text style={s.chipT}>{t}</Text></Pressable>
);

const s = StyleSheet.create({
  empty: { color: colors.textDim, padding: 16 },
  row: { backgroundColor: colors.panel, borderRadius: radius.sm, padding: 10, borderWidth: 1, borderColor: 'transparent' },
  rowSel: { borderColor: colors.purple },
  name: { color: colors.text, fontWeight: '600' },
  type: { color: colors.textDim, fontSize: 12, fontWeight: '400' },
  actions: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 8 },
  chip: { borderWidth: 1, borderColor: colors.border, borderRadius: 6, paddingVertical: 6, paddingHorizontal: 10 },
  chipT: { color: colors.text, fontSize: 12 },
});
