import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Transform } from '@/projects/schema';
import { NumberField, CommitText } from '@/components/NumberField';
import { useEditorStore } from './useEditorStore';
import { setComposition, setTransformValue, updateContent, updateLayer, renameProject } from './commands';
import { colors, radius } from '@/theme';

const SWATCHES = ['#FFFFFF', '#000000', '#8B5CF6', '#3B82F6', '#14B8A6', '#22C55E', '#F59E0B', '#F0506E'];

function Swatches({ value, onPick }: { value?: string; onPick: (c: string) => void }) {
  return (
    <View style={s.sw}>
      {SWATCHES.map((c) => (
        <Pressable key={c} onPress={() => onPick(c)} style={[s.swatch, { backgroundColor: c }, value?.toUpperCase() === c && s.swatchOn]} />
      ))}
    </View>
  );
}

export function PropertiesPanel() {
  const project = useEditorStore((s) => s.project)!;
  const selectedId = useEditorStore((s) => s.selectedId);
  const { apply } = useEditorStore.getState();
  const layer = project.composition.layers.find((l) => l.id === selectedId);
  const comp = project.composition;

  if (!layer) {
    return (
      <ScrollView contentContainerStyle={s.pad}>
        <Text style={s.h}>Composição</Text>
        <CommitText label="Nome do projeto" value={project.name} onCommit={(v) => apply(renameProject(v.trim() || project.name))} />
        <View style={s.row}>
          <NumberField label="Duração (s)" value={comp.duration} step={1} min={1} max={600} decimals={1} onCommit={(v) => apply(setComposition({ duration: v }))} />
        </View>
        <Text style={s.label}>Cor de fundo</Text>
        <Swatches value={comp.backgroundColor} onPick={(c) => apply(setComposition({ backgroundColor: c }))} />
        <Text style={s.note}>Toque numa camada para editar suas propriedades.</Text>
      </ScrollView>
    );
  }
  const c = layer.content ?? {};
  const tf = (key: keyof Transform, label: string, extra: { step?: number; min?: number; max?: number; decimals?: number } = {}) => (
    <NumberField label={label} value={layer.transform[key].value} onCommit={(v) => apply(setTransformValue(layer.id, key, v))} {...extra} />
  );
  return (
    <ScrollView contentContainerStyle={s.pad} keyboardShouldPersistTaps="handled">
      <CommitText label="Nome" value={layer.name} onCommit={(v) => apply(updateLayer(layer.id, { name: v.trim() || layer.name }))} />
      {layer.type === 'text' && (
        <>
          <CommitText label="Texto" value={c.text ?? ''} multiline onCommit={(v) => apply(updateContent(layer.id, { text: v }))} />
          <View style={s.row}>
            <NumberField label="Tamanho da fonte" value={c.fontSize ?? 64} step={4} min={4} max={1000} onCommit={(v) => apply(updateContent(layer.id, { fontSize: v }))} />
          </View>
        </>
      )}
      {(layer.type === 'solid' || layer.type === 'shape' || layer.type === 'text') && (
        <>
          <Text style={s.label}>Cor</Text>
          <Swatches value={c.color} onPick={(col) => apply(updateContent(layer.id, { color: col }))} />
        </>
      )}
      {layer.type === 'shape' && (
        <View style={s.row}>
          <NumberField label="Largura" value={c.width ?? 100} step={10} min={1} max={10000} onCommit={(v) => apply(updateContent(layer.id, { width: v }))} />
          <NumberField label="Altura" value={c.height ?? 100} step={10} min={1} max={10000} onCommit={(v) => apply(updateContent(layer.id, { height: v }))} />
        </View>
      )}
      <Text style={s.h}>Transformação</Text>
      <View style={s.row}>{tf('positionX', 'Posição X', { step: 10 })}{tf('positionY', 'Posição Y', { step: 10 })}</View>
      <View style={s.row}>{tf('scaleX', 'Escala X (%)', { step: 5, min: 0 })}{tf('scaleY', 'Escala Y (%)', { step: 5, min: 0 })}</View>
      <View style={s.row}>{tf('rotation', 'Rotação (°)', { step: 5 })}{tf('opacity', 'Opacidade (%)', { step: 5, min: 0, max: 100 })}</View>
      <Text style={s.h}>Tempo</Text>
      <View style={s.row}>
        <NumberField label="Início (s)" value={layer.startTime} step={0.1} min={0} max={comp.duration} decimals={2}
          onCommit={(v) => apply(updateLayer(layer.id, { startTime: Math.min(v, Math.max(0, comp.duration - layer.duration)) }))} />
        <NumberField label="Duração (s)" value={layer.duration} step={0.1} min={0.1} max={comp.duration} decimals={2}
          onCommit={(v) => apply(updateLayer(layer.id, { duration: Math.min(v, comp.duration - layer.startTime) }))} />
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  pad: { padding: 12, paddingBottom: 24 },
  h: { color: colors.text, fontWeight: '700', marginTop: 6, marginBottom: 8 },
  label: { color: colors.textDim, fontSize: 11, marginBottom: 4 },
  row: { flexDirection: 'row', gap: 10, marginBottom: 10 },
  sw: { flexDirection: 'row', gap: 8, marginBottom: 10 },
  swatch: { width: 30, height: 30, borderRadius: 15, borderWidth: 1, borderColor: colors.border },
  swatchOn: { borderWidth: 3, borderColor: colors.purple },
  note: { color: colors.textDim, fontSize: 12, marginTop: 6 },
});
